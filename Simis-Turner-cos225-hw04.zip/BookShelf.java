import java.util.ArrayList;
public class BookShelf {
    private char firstLetter;
    private ArrayList<Book> books;
    //Defualt constructor
    public BookShelf(char firstLetter){
        this.firstLetter=firstLetter;
        this.books=new ArrayList<>();
    }
    //Getters/setters
    public char gFirstLetter(){
        return firstLetter;
    }
    public ArrayList<Book> gBooks(){
        return books;
    }
    public void addBook(Book book){
        if (book.title.charAt(0)==firstLetter){
            books.add(book);
        }else{
            return;
        }
    }
    public void removeBook(Book book) {
        books.remove(book);
    }
    public String toString(){
        String booksOnShelf="";
        if (books.isEmpty()){
            return "empty";
        }
        for (int i =0;i<books.size();i++){
            booksOnShelf=booksOnShelf+books.get(i).gTitle()+"   ";
        }
        return booksOnShelf;
    }
}
