public class Book{
    public String title;
    private String genre;
    //Constructor
    public Book(String title, String genre){
        this.title=title;
        this.genre=genre;
    }
    public String toString(){
        return title;
    }
    public String gTitle(){
        return title;
    }
}