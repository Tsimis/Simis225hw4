public class LibraryTester {
    public static void main(String[] args) {
        BookShelf bookShelfO=new BookShelf('O');
        BookShelf bookShelfT=new BookShelf('T');
        System.out.println(bookShelfO.toString());
        System.out.println(bookShelfT.toString());
        Book book1 = new Book("The Heart of the Betrayed", "Crime");
        Book book2 = new Book("Our Hill of Stars", "Fantasy");
        Book book3 = new Book("One of a Kind", "Science Fiction");
        Book book4 = new Book("The Vision of Roses", "Romance");
        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);
        System.out.println(book4);
        bookShelfO.addBook(book1);
        bookShelfO.addBook(book2);
        bookShelfO.addBook(book3);
        bookShelfO.addBook(book4);
        bookShelfT.addBook(book1);
        bookShelfT.addBook(book2);
        bookShelfT.addBook(book3);
        bookShelfT.addBook(book4);
        System.out.println(bookShelfO.toString());
        System.out.println(bookShelfT.toString());
    }
}
